import streamlit as st
import pandas as pd
import numpy as np
import joblib
import plotly.express as px
import plotly.graph_objects as go

# =========================
# LOAD FILES
# =========================
model = joblib.load("model.pkl")
scaler = joblib.load("scaler.pkl")
columns = joblib.load("columns.pkl")

# Load additional files if they exist
try:
    xgb_model = joblib.load("xgb_model.pkl")
    results_df = joblib.load("results.pkl")
except:
    xgb_model = None
    results_df = None

# =========================
# PAGE CONFIG
# =========================
st.set_page_config(
    page_title="Diabetes Predictor", 
    layout="wide", 
    page_icon="🩺",
    initial_sidebar_state="expanded"
)

# =========================
# CUSTOM CSS
# =========================
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 1rem;
    }
    .sub-header {
        font-size: 1.5rem;
        font-weight: bold;
        color: #2ca02c;
        margin-top: 1rem;
    }
    .metric-card {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 0.5rem;
        border-left: 0.25rem solid #1f77b4;
    }
    .sidebar .sidebar-content {
        background-color: #f8f9fa;
    }
</style>
""", unsafe_allow_html=True)

# =========================
# SIDEBAR
# =========================
with st.sidebar:
    st.image("https://img.icons8.com/color/96/000000/diabetes.png", width=80)
    st.header("ℹ️ About")
    st.write("This advanced app uses machine learning to predict diabetes risk based on comprehensive health data.")
    st.markdown("**Model:** Voting Ensemble")
    st.markdown("**Accuracy:** ~91%")
    st.markdown("**Best Model:** Decision Tree (F1: 0.92)")
    st.markdown("---")
    st.header("📊 Dataset Features")
    st.write("• 41 health indicators")
    st.write("• Demographics & lifestyle")
    st.write("• Medical history & labs")
    st.markdown("---")
    st.header("🔗 Links")
    st.write("[GitHub Repository](https://github.com)")
    st.write("[Medical Guidelines](https://www.cdc.gov/diabetes)")

# =========================
# MAIN CONTENT - TABS
# =========================
st.markdown('<h1 class="main-header">🩺 Advanced Diabetes Risk Prediction</h1>', unsafe_allow_html=True)
st.markdown("### Comprehensive AI-powered diabetes risk assessment")

tab1, tab2, tab3, tab4 = st.tabs(["🔍 Prediction", "📈 Model Performance", "🎯 Feature Importance", "ℹ️ About"])

# =========================
# TAB 1: PREDICTION
# =========================
with tab1:
    st.markdown('<h2 class="sub-header">Patient Risk Assessment</h2>', unsafe_allow_html=True)
    st.write("Enter patient details below for a comprehensive diabetes risk evaluation.")

    # Demographics
    st.subheader("👤 Demographics")
    col1, col2, col3 = st.columns(3)

    with col1:
        age = st.slider("Age", 10, 100, 30, help="Patient's age in years")

    with col2:
        gender = st.selectbox("Gender", ["Female", "Male", "Other"], help="Biological gender")

    with col3:
        ethnicity = st.selectbox("Ethnicity", ["Asian", "Black", "Hispanic", "Other", "White"], help="Ethnic background")

    # Lifestyle
    st.subheader("🏃 Lifestyle Factors")
    col1, col2 = st.columns(2)

    with col1:
        alcohol = st.slider("Alcohol Consumption (drinks/week)", 0, 50, 5, help="Number of alcoholic drinks per week")

    with col2:
        physical_activity = st.slider("Physical Activity (minutes/week)", 0, 1000, 150, help="Minutes of moderate exercise per week")

    col1, col2, col3 = st.columns(3)

    with col1:
        sleep_hours = st.slider("Sleep Hours per Day", 4, 12, 8, help="Average hours of sleep per night")

    with col2:
        screen_time = st.slider("Screen Time (hours/day)", 0, 24, 4, help="Daily screen time in hours")

    with col3:
        smoking = st.selectbox("Smoking Status", ["Never", "Former", "Current"], help="Smoking history")

    # Medical History
    st.subheader("🏥 Medical History")
    col1, col2, col3 = st.columns(3)

    with col1:
        family_history = st.selectbox("Family History of Diabetes", ["No", "Yes"], help="Does family have diabetes history?")

    with col2:
        hypertension = st.selectbox("Hypertension History", ["No", "Yes"], help="History of high blood pressure?")

    with col3:
        cardiovascular = st.selectbox("Cardiovascular History", ["No", "Yes"], help="History of heart disease?")

    # Measurements
    st.subheader("📏 Physical Measurements")
    col1, col2, col3 = st.columns(3)

    with col1:
        bmi = st.slider("BMI", 10.0, 50.0, 25.0, help="Body Mass Index")

    with col2:
        waist_hip = st.slider("Waist-to-Hip Ratio", 0.5, 1.5, 0.9, help="Waist circumference divided by hip circumference")

    with col3:
        heart_rate = st.slider("Heart Rate (bpm)", 50, 150, 70, help="Resting heart rate")

    # Blood Pressure
    st.subheader("🩸 Blood Pressure")
    col1, col2 = st.columns(2)

    with col1:
        systolic_bp = st.slider("Systolic BP", 80, 200, 120, help="Systolic blood pressure (mmHg)")

    with col2:
        diastolic_bp = st.slider("Diastolic BP", 50, 120, 80, help="Diastolic blood pressure (mmHg)")

    # Lab Results
    st.subheader("🧪 Laboratory Results")
    col1, col2, col3 = st.columns(3)

    with col1:
        cholesterol_total = st.slider("Total Cholesterol", 100, 300, 180, help="Total cholesterol (mg/dL)")

    with col2:
        hdl = st.slider("HDL Cholesterol", 20, 100, 50, help="HDL (good) cholesterol (mg/dL)")

    with col3:
        ldl = st.slider("LDL Cholesterol", 50, 200, 100, help="LDL (bad) cholesterol (mg/dL)")

    col1, col2, col3 = st.columns(3)

    with col1:
        triglycerides = st.slider("Triglycerides", 50, 500, 150, help="Triglyceride level (mg/dL)")

    with col2:
        glucose_fasting = st.slider("Fasting Glucose", 50, 200, 100, help="Fasting blood glucose (mg/dL)")

    with col3:
        glucose_post = st.slider("Postprandial Glucose", 50, 300, 140, help="Blood glucose 2 hours after eating (mg/dL)")

    col1, col2, col3 = st.columns(3)

    with col1:
        insulin = st.slider("Insulin Level", 2, 50, 10, help="Insulin level (µU/mL)")

    with col2:
        hba1c = st.slider("HbA1c (%)", 3.0, 15.0, 5.5, help="Hemoglobin A1c percentage")

    with col3:
        diabetes_risk_score = st.slider("Diabetes Risk Score", 0, 100, 20, help="Overall diabetes risk score")

    # PREDICTION BUTTON
    st.markdown("---")
    col1, col2, col3 = st.columns([1,2,1])
    with col2:
        predict_button = st.button("🔍 Predict Diabetes Risk", type="primary", use_container_width=True)

    if predict_button:
        
        # PREPARE INPUT DATA
        input_dict = {col: 0 for col in columns}
        
        # Fill in the values
        input_dict["age"] = age
        input_dict["alcohol_consumption_per_week"] = alcohol
        input_dict["physical_activity_minutes_per_week"] = physical_activity
        input_dict["sleep_hours_per_day"] = sleep_hours
        input_dict["screen_time_hours_per_day"] = screen_time
        input_dict["bmi"] = bmi
        input_dict["waist_to_hip_ratio"] = waist_hip
        input_dict["systolic_bp"] = systolic_bp
        input_dict["diastolic_bp"] = diastolic_bp
        input_dict["heart_rate"] = heart_rate
        input_dict["cholesterol_total"] = cholesterol_total
        input_dict["hdl_cholesterol"] = hdl
        input_dict["ldl_cholesterol"] = ldl
        input_dict["triglycerides"] = triglycerides
        input_dict["glucose_fasting"] = glucose_fasting
        input_dict["glucose_postprandial"] = glucose_post
        input_dict["insulin_level"] = insulin
        input_dict["hba1c"] = hba1c
        input_dict["diabetes_risk_score"] = diabetes_risk_score
        
        # Categorical encodings
        if gender == "Male":
            input_dict["gender_Male"] = 1
        elif gender == "Other":
            input_dict["gender_Other"] = 1
            
        if ethnicity == "Black":
            input_dict["ethnicity_Black"] = 1
        elif ethnicity == "Hispanic":
            input_dict["ethnicity_Hispanic"] = 1
        elif ethnicity == "Other":
            input_dict["ethnicity_Other"] = 1
        elif ethnicity == "White":
            input_dict["ethnicity_White"] = 1
            
        # Default socioeconomic values (no encoding needed for "Undergraduate", "Middle", "Employed")
            
        if smoking == "Former":
            input_dict["smoking_status_Former"] = 1
        
        if family_history == "Yes":
            input_dict["family_history_diabetes"] = 1
            
        if hypertension == "Yes":
            input_dict["hypertension_history"] = 1
            
        if cardiovascular == "Yes":
            input_dict["cardiovascular_history"] = 1

        # Convert to DataFrame
        input_df = pd.DataFrame([input_dict])

        # Scale input
        input_scaled = scaler.transform(input_df)

        # Predict
        prediction = model.predict(input_scaled)[0]
        probability = model.predict_proba(input_scaled)[0][1]

        # OUTPUT
        st.markdown("---")
        st.header("🎯 Prediction Results")
        
        col1, col2 = st.columns(2)
        
        with col1:
            if prediction == 1:
                st.error("⚠️ **High Risk of Diabetes**")
                st.write("Based on the provided information, you are at high risk for diabetes.")
            else:
                st.success("✅ **Low Risk of Diabetes**")
                st.write("Based on the provided information, you are at low risk for diabetes.")
        
        with col2:
            st.metric("Risk Probability", f"{probability:.1%}")
            st.progress(probability)
            
            if probability > 0.7:
                risk_level = "High"
                color = "🔴"
            elif probability > 0.4:
                risk_level = "Medium"
                color = "🟡"
            else:
                risk_level = "Low"
                color = "🟢"
                
            st.write(f"**Risk Level:** {color} {risk_level}")

        # Show input summary
        st.markdown("---")
        st.subheader("📋 Input Summary")
        
        summary_data = {
            "Category": ["Demographics", "Lifestyle", "Medical History", "Measurements", "Blood Pressure", "Lab Results"],
            "Details": [
                f"Age: {age}, Gender: {gender}, Ethnicity: {ethnicity}",
                f"Alcohol: {alcohol}/week, Exercise: {physical_activity} min/week",
                f"Family History: {family_history}, Hypertension: {hypertension}, Cardiovascular: {cardiovascular}",
                f"BMI: {bmi}, Waist-Hip: {waist_hip}, Heart Rate: {heart_rate}",
                f"Systolic: {systolic_bp}, Diastolic: {diastolic_bp}",
                f"Glucose: {glucose_fasting}/{glucose_post}, HbA1c: {hba1c}%, Insulin: {insulin}"
            ]
        }
        
        summary_df = pd.DataFrame(summary_data)
        st.table(summary_df)
        
        # Recommendations
        st.markdown("---")
        st.subheader("💡 Recommendations")
        
        if prediction == 1:
            st.warning("Consider consulting a healthcare professional for further evaluation.")
            if bmi > 25:
                st.write("• Maintain healthy BMI through diet and exercise")
            if glucose_fasting > 100:
                st.write("• Monitor blood glucose levels regularly")
            if physical_activity < 150:
                st.write("• Increase physical activity to at least 150 minutes per week")
        else:
            st.info("Keep up the good work! Continue healthy lifestyle choices.")
            st.write("• Regular health check-ups")
            st.write("• Balanced diet and exercise")

# =========================
# TAB 2: MODEL PERFORMANCE
# =========================
with tab2:
    st.markdown('<h2 class="sub-header">Model Performance Metrics</h2>', unsafe_allow_html=True)
    st.write("Comparison of different machine learning models used in the ensemble.")
    
    if results_df is not None:
        # Display the results table
        st.dataframe(results_df.style.highlight_max(axis=0), use_container_width=True)
        
        # Create a bar chart for F1 Scores
        fig = px.bar(results_df, x='Model', y='F1 Score', 
                     title='Model F1 Scores Comparison',
                     color='F1 Score', color_continuous_scale='Blues')
        fig.update_layout(xaxis_title="Model", yaxis_title="F1 Score")
        st.plotly_chart(fig, use_container_width=True)
        
        # Metrics overview
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Best Accuracy", f"{results_df['Accuracy'].max():.3f}")
        with col2:
            st.metric("Best Precision", f"{results_df['Precision'].max():.3f}")
        with col3:
            st.metric("Best Recall", f"{results_df['Recall'].max():.3f}")
        with col4:
            st.metric("Best F1 Score", f"{results_df['F1 Score'].max():.3f}")
    else:
        st.error("Model performance data not available. Please run the training script first.")

# =========================
# TAB 3: FEATURE IMPORTANCE
# =========================
with tab3:
    st.markdown('<h2 class="sub-header">Feature Importance Analysis</h2>', unsafe_allow_html=True)
    st.write("Understanding which health factors contribute most to diabetes prediction.")
    
    if xgb_model is not None:
        # Get feature importances
        importances = xgb_model.feature_importances_
        feature_names = columns
        
        # Create DataFrame
        importance_df = pd.DataFrame({
            'Feature': feature_names,
            'Importance': importances
        }).sort_values('Importance', ascending=False).head(20)  # Top 20
        
        # Bar chart
        fig = px.bar(importance_df, x='Importance', y='Feature', orientation='h',
                     title='Top 20 Feature Importances (XGBoost)',
                     color='Importance', color_continuous_scale='Reds')
        fig.update_layout(xaxis_title="Importance Score", yaxis_title="Feature")
        st.plotly_chart(fig, use_container_width=True)
        
        # Summary
        st.subheader("Key Insights")
        top_features = importance_df.head(5)['Feature'].tolist()
        st.write(f"**Top 5 most important features:** {', '.join(top_features)}")
        st.write("These factors have the strongest influence on diabetes risk prediction.")
    else:
        st.error("Feature importance data not available. Please run the training script first.")

# =========================
# TAB 4: ABOUT
# =========================
with tab4:
    st.markdown('<h2 class="sub-header">About This Application</h2>', unsafe_allow_html=True)
    
    st.write("""
    This diabetes prediction application uses advanced machine learning techniques to assess an individual's risk of developing diabetes based on comprehensive health data.
    
    ### 🧠 Machine Learning Model
    - **Ensemble Method**: Voting Classifier combining AdaBoost, XGBoost, and Gradient Boosting
    - **Data Balancing**: SMOTEENN technique to handle class imbalance
    - **Evaluation**: F1 Score of 0.92 on test data
    
    ### 📊 Dataset
    - 41 health indicators including demographics, lifestyle, medical history, and laboratory results
    - Preprocessed with feature scaling and categorical encoding
    - Trained on balanced dataset using advanced sampling techniques
    
    ### 🎯 Features
    - Real-time risk prediction
    - Comprehensive input validation
    - Personalized health recommendations
    - Model performance insights
    - Feature importance analysis
    
    ### ⚠️ Disclaimer
    This tool is for educational and informational purposes only. It should not replace professional medical advice, diagnosis, or treatment. Always consult with qualified healthcare providers for medical concerns.
    """)
    
    st.markdown("---")
    st.subheader("🔧 Technical Details")
    st.write("Built with: Python, Streamlit, Scikit-learn, XGBoost, Pandas, NumPy, Plotly")
    st.write("Developed for: Diabetes risk assessment and health education")