import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split, learning_curve
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
from sklearn.metrics import roc_curve, auc, precision_recall_curve

from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import GradientBoostingClassifier, AdaBoostClassifier, VotingClassifier

from xgboost import XGBClassifier
from imblearn.combine import SMOTEENN



df = pd.read_csv("diabetes.csv")


#  PREPROCESSING

X = df.drop(["diagnosed_diabetes", "diabetes_stage"], axis=1)
Y = df["diagnosed_diabetes"]

# Encoding categorical
X = pd.get_dummies(X, drop_first=True)

# SAVE COLUMNS HERE 
import joblib
joblib.dump(X.columns, "columns.pkl")

# Scaling
scaler = StandardScaler()
X = scaler.fit_transform(X)


#  SPLIT DATA

X_train, X_test, Y_train, Y_test = train_test_split(
    X, Y, test_size=0.2, random_state=42
)


#  HANDLE IMBALANCE

smote = SMOTEENN(random_state=42)
X_train_sm, Y_train_sm = smote.fit_resample(X_train, Y_train)


#  MODEL TRAINING

best_lr = LogisticRegression(max_iter=1000).fit(X_train_sm, Y_train_sm)
best_knn = KNeighborsClassifier(n_neighbors=7).fit(X_train_sm, Y_train_sm)
best_dt = DecisionTreeClassifier(max_depth=5).fit(X_train_sm, Y_train_sm)
best_gb = GradientBoostingClassifier().fit(X_train_sm, Y_train_sm)
best_ada = AdaBoostClassifier().fit(X_train_sm, Y_train_sm)
best_xgb = XGBClassifier(eval_metric='logloss').fit(X_train_sm, Y_train_sm)


#  VOTING ENSEMBLE

voting_model = VotingClassifier(
    estimators=[
        ('ada', best_ada),
        ('xgb', best_xgb),
        ('gb', best_gb)
    ],
    voting='soft'
)

voting_model.fit(X_train_sm, Y_train_sm)


#  MODEL COMPARISON

models = {
    "Voting": voting_model,
    "AdaBoost": best_ada,
    "XGBoost": best_xgb,
    "Gradient Boosting": best_gb,
    "KNN": best_knn,
    "Logistic Regression": best_lr,
    "Decision Tree": best_dt
}

results = []

for name, model in models.items():
    y_pred = model.predict(X_test)
    
    results.append({
        "Model": name,
        "Accuracy": accuracy_score(Y_test, y_pred),
        "Precision": precision_score(Y_test, y_pred),
        "Recall": recall_score(Y_test, y_pred),
        "F1 Score": f1_score(Y_test, y_pred)
    })

results_df = pd.DataFrame(results).sort_values(by="F1 Score", ascending=False)
print("\nFinal Model Comparison:\n")
print(results_df)


#  CONFUSION MATRIX

y_pred = voting_model.predict(X_test)

cm = confusion_matrix(Y_test, y_pred)
disp = ConfusionMatrixDisplay(confusion_matrix=cm)
disp.plot()

plt.title("Confusion Matrix - Voting Ensemble")
plt.show()


#  ROC CURVE

y_prob = voting_model.predict_proba(X_test)[:,1]

fpr, tpr, _ = roc_curve(Y_test, y_prob)
roc_auc = auc(fpr, tpr)

plt.figure()
plt.plot(fpr, tpr, label=f"AUC = {roc_auc:.2f}")
plt.plot([0,1], [0,1], linestyle='--')

plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC Curve - Voting Ensemble")
plt.legend()
plt.show()


#  PRECISION-RECALL CURVE

precision, recall, _ = precision_recall_curve(Y_test, y_prob)

plt.figure()
plt.plot(recall, precision)

plt.xlabel("Recall")
plt.ylabel("Precision")
plt.title("Precision-Recall Curve - Voting Ensemble")
plt.show()


#  LEARNING CURVE (UNDER/OVERFITTING)

train_sizes, train_scores, test_scores = learning_curve(
    voting_model, X, Y, cv=5, scoring='accuracy',
    train_sizes=np.linspace(0.1, 1.0, 10), n_jobs=-1
)

train_mean = np.mean(train_scores, axis=1)
test_mean = np.mean(test_scores, axis=1)

plt.figure()
plt.plot(train_sizes, train_mean, label="Training Score")
plt.plot(train_sizes, test_mean, label="Validation Score")

plt.xlabel("Training Size")
plt.ylabel("Accuracy")
plt.title("Learning Curve (Underfitting vs Overfitting)")
plt.legend()
plt.show()


#  BEST MODEL SELECTION


# Select best model based on F1 Score
best_row = results_df.iloc[0]

best_model_name = best_row["Model"]
best_f1 = best_row["F1 Score"]

print("")
print(" BEST MODEL SELECTION")
print("")
print(f"Best Model: {best_model_name}")
print(f"F1 Score: {best_f1:.4f}")


best_model = models[best_model_name]


# FINAL EVALUATION OF BEST MODEL


y_pred_best = best_model.predict(X_test)

print("\nFinal Evaluation of Best Model:")
print("Accuracy:", accuracy_score(Y_test, y_pred_best))
print("Precision:", precision_score(Y_test, y_pred_best))
print("Recall:", recall_score(Y_test, y_pred_best))
print("F1 Score:", f1_score(Y_test, y_pred_best))


import joblib

joblib.dump(voting_model, "model.pkl")
joblib.dump(scaler, "scaler.pkl")
joblib.dump(df.drop(["diagnosed_diabetes", "diabetes_stage"], axis=1)
            .pipe(pd.get_dummies, drop_first=True)
            .columns,
            "columns.pkl")

joblib.dump(best_xgb, "xgb_model.pkl")
joblib.dump(results_df, "results.pkl")